<!DOCTYPE html><html lang="en"><head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Bus</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css" media="screen">
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
 </head>
 <!-- body -->
 <body class="main-layout">
    <!-- loader  -->
    <div class="loader_bg">
       <div class="loader"><img src="images/loading.gif" alt="#"></div>
    </div>
    <!-- end loader -->
  <!-- header -->
  <header>
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="t-hdr">
                        <ul>
                            <li><i class="fa-solid fa-phone"></i> <a href="tel:+919431163344">+919431163344</a></li>
                            <li><i class="fa-solid fa-envelope"></i><a href="mailto:highwayhzb@gmail.com">highwayhzb@gmail.com</a></li>                                
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <p style="text-align: right;"><i class="fa-solid fa-location-dot"></i> New Forest Colony, Hazaribagh, Jharkhand 825301</p>
                </div>
            </div>
        </div>
    </div>
   <!-- header inner -->
   <div class="header">
      <div class="container">
         <div class="row">
            <div class="col-xl-4 col-lg-3 col-md-3 col-sm-3 col logo_section">
               <div class="full">
                  <div class="center-desk">
                     <div class="logo">
                        <a href="index.html"><img src="images/logo2.png" alt="#"></a>
                     </div>
                     <p>Highway Tour And Travel</p>
                  </div>
               </div>
            </div>
            <div class="col-xl-8 col-lg-9 col-md-9 col-sm-9">
               <nav class="navigation navbar navbar-expand-md navbar-dark ">
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarsExample04">
                     <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                           <a class="nav-link" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="about.html">About</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="bus.html">Our Bus</a>
                        </li>
                        <li class="nav-item active">
                           <a class="nav-link" href="gallery.html">Gallery</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="contact.html">Contact</a>
                        </li>

                        <li><a href="/#book-ticket" class="hdr-btn">Book Now</a></li>
                        <li><a href="" class="hdr-btn">Cancel Ticket</a></li>
                     </ul>
                  </div>
               </nav>
            </div>
         </div>
      </div>
   </div>
</header>
<!-- end header inner -->
    <!-- end header -->
   <div class="back_re">
       <div class="container">
          <div class="row">
             <div class="col-md-12">
                <div class="title">
                    <h2>our Gallery</h2>
                </div>
             </div>
          </div>
       </div>
    </div>


  <footer>
    <div class="footer">
       <div class="container">
          <div class="row">
             <div class="col-lg-3 col-md-6">
                 <div class="ftr-content">
                     <div>
                         <img src="images/logo2.png" alt="">
                     </div>
                     <h3>Highway Tour And Travel</h3>
                     <p>Letius quis dui at lectus congue natoque et adipiscing curabitur molestie. Mattis magnis ...</p>
                 </div>
             </div>
             <div class="col-lg-3 col-md-6">
                <h3>Quick Link</h3>
                <ul class="link_menu">
                   <li><a href="#">Home</a></li>
                   <li><a href="about.html"> about</a></li>
                   <li><a href="room.html">Our bus</a></li>
                   <li><a href="gallery.html">Gallery</a></li>
                   <li><a href="contact.html">Contact Us</a></li>
                </ul>
             </div>
             <div class="col-lg-3 col-md-6">
                 <h3>Travel Resources</h3>
                 <ul class="link_menu">
                    <li>Holidays Packages</li>
                    <li>Railways Ticket</li>
                    <li>Customer Support</li>
                    <li>Cancel Bookings</li>
                    <li>Print E-tickets</li>
                    <li>Domesic Flight</li>
                 </ul>
              </div>
             <div class="col-lg-3 col-md-6">
                 <h3>Contact US</h3>
                 <ul class="conta">
                    <li class="d-flex"><i class="fa fa-map-marker" aria-hidden="true"></i> <p>New Forest Colony, Hazaribagh, Jharkhand 825301</p></li>
                    <li><i class="fa fa-mobile" aria-hidden="true"></i> +91 9431163344</li>
                    <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"> highwayhzb@gmail.com</a></li>
                 </ul>
                 <ul class="list-unstyled jcnascc">
     
                     <li>
                         <a href="https://www.facebook.com/skillbook024?mibextid=kFxxJD" target="_blank"><i class="fab fa-facebook"></i><span></span></a>
                     </li>
                     <li>
                         <a href="https://www.instagram.com/skillbook024?igsh=MXRrN3cyaTF0NHpoOA%3D%3D" target="_blank"><i class="fab fa-instagram"></i><span></span></a>
                     </li>
                     <li>
                         <a href="https://www.youtube.com/@SkillBook/videos" target="_blank"><i class="fab fa-youtube"></i><span></span></a>
                     </li>
                     <li><a href="#" target="_blank"><i class="fab fa-twitter"></i> <span></span></a></li>
             </ul>
              </div>
          </div>
       </div>
       <div class="copyright">
          <div class="container">
             <div class="row">
                <div class="col-md-10 offset-md-1">
                   <p>Copyrights © 2017 Highway Tour And Travels. Developed by <a href="">Appizum</a></p>
                </div>
             </div>
          </div>
       </div>
    </div>
 </footer>
 <!-- end footer -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <!-- sidebar -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>
 
</body></html>