<?php
require '../includes/header.php';
require '../includes/db.php';

$bookings = $pdo->query("
    SELECT b.*, u.name as user_name, bs.bus_number 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN buses bs ON b.bus_id = bs.id
")->fetchAll();
?>

<div class="container">
    <h1>Bookings</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Bus</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bookings as $booking): ?>
            <tr>
                <td><?= $booking['id'] ?></td>
                <td><?= $booking['user_name'] ?></td>
                <td><?= $booking['bus_number'] ?></td>
                <td><?= $booking['status'] ?></td>
                <td>$<?= number_format($booking['amount'], 2) ?></td>
                <td>
                    <a href="view.php?id=<?= $booking['id'] ?>" class="btn btn-sm btn-info">View</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require '../includes/footer.php'; ?> 