<?php
require 'includes/header.php';
require 'includes/db.php';

// Get dashboard stats
$totalBookings = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalRevenue = $pdo->query("SELECT SUM(amount) FROM bookings WHERE status = 'confirmed'")->fetchColumn();
$activeBuses = $pdo->query("SELECT COUNT(*) FROM buses WHERE status = 'active'")->fetchColumn();
?>

<div class="container">
    <h1>Dashboard</h1>
    <div class="stats">
        <div class="stat-card">
            <h3>Total Bookings</h3>
            <p><?= $totalBookings ?></p>
        </div>
        <div class="stat-card">
            <h3>Total Revenue</h3>
            <p>$<?= number_format($totalRevenue, 2) ?></p>
        </div>
        <div class="stat-card">
            <h3>Active Buses</h3>
            <p><?= $activeBuses ?></p>
        </div>
    </div>
</div>

<?php require 'includes/footer.php'; ?> 