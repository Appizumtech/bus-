<?php
require '../includes/header.php';
require '../includes/db.php';

$buses = $pdo->query("SELECT * FROM buses")->fetchAll();
?>

<div class="container">
    <h1>Buses</h1>
    <a href="create.php" class="btn btn-primary">Add New Bus</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Bus Number</th>
                <th>Route</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($buses as $bus): ?>
            <tr>
                <td><?= $bus['id'] ?></td>
                <td><?= $bus['bus_number'] ?></td>
                <td><?= $bus['route'] ?></td>
                <td><?= $bus['status'] ?></td>
                <td>
                    <a href="edit.php?id=<?= $bus['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php require '../includes/footer.php'; ?> 