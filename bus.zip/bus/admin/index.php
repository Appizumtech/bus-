<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

include '../includes/db_connection.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard - Bus Booking</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: #192080;
            color: white;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 15px 20px;
            border-radius: 4px;
            margin: 5px 0;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }
        .main-content {
            padding: 20px;
        }
        .stats-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .stats-card h3 {
            color: #192080;
            margin-bottom: 10px;
        }
        .stats-card p {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
        }
        .stats-card i {
            font-size: 40px;
            color: #192080;
            opacity: 0.1;
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar py-4">
                <div class="text-center mb-4">
                    <h4>Admin Panel</h4>
                </div>
                <nav class="nav flex-column">
                    <a class="nav-link active" href="index.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus"></i> Manage Buses
                    </a>
                    <a class="nav-link" href="bookings.php">
                        <i class="fas fa-ticket-alt"></i> Bookings
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route"></i> Routes
                    </a>
                    <a class="nav-link" href="users.php">
                        <i class="fas fa-users"></i> Users
                    </a>
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <h2 class="mb-4">Dashboard</h2>
                
                <div class="row">
                    <!-- Total Bookings -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stats-card position-relative">
                            <h3>Total Bookings</h3>
                            <?php
                            $sql = "SELECT COUNT(*) as count FROM bookings";
                            $result = $conn->query($sql);
                            $bookings = $result->fetch_assoc();
                            ?>
                            <p><?php echo $bookings['count']; ?></p>
                            <i class="fas fa-ticket-alt"></i>
                        </div>
                    </div>

                    <!-- Active Buses -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stats-card position-relative">
                            <h3>Active Buses</h3>
                            <?php
                            $sql = "SELECT COUNT(*) as count FROM buses";
                            $result = $conn->query($sql);
                            $buses = $result->fetch_assoc();
                            ?>
                            <p><?php echo $buses['count']; ?></p>
                            <i class="fas fa-bus"></i>
                        </div>
                    </div>

                    <!-- Total Revenue -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stats-card position-relative">
                            <h3>Total Revenue</h3>
                            <?php
                            $sql = "SELECT SUM(total_amount) as total FROM bookings";
                            $result = $conn->query($sql);
                            $revenue = $result->fetch_assoc();
                            ?>
                            <p>₹<?php echo number_format($revenue['total'] ?? 0, 2); ?></p>
                            <i class="fas fa-rupee-sign"></i>
                        </div>
                    </div>

                    <!-- Available Seats -->
                    <div class="col-md-6 col-lg-3">
                        <div class="stats-card position-relative">
                            <h3>Available Seats</h3>
                            <?php
                            $sql = "SELECT SUM(available_seats) as seats FROM buses";
                            $result = $conn->query($sql);
                            $seats = $result->fetch_assoc();
                            ?>
                            <p><?php echo $seats['seats']; ?></p>
                            <i class="fas fa-chair"></i>
                        </div>
                    </div>
                </div>

                <!-- Recent Bookings -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="mb-0">Recent Bookings</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Booking ID</th>
                                    <th>Passenger Name</th>
                                    <th>Bus</th>
                                    <th>Travel Date</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT b.*, p.name as passenger_name, bs.name as bus_name 
                                       FROM bookings b 
                                       JOIN passengers p ON b.passenger_id = p.id 
                                       JOIN buses bs ON b.bus_id = bs.id 
                                       ORDER BY b.booking_date DESC LIMIT 5";
                                $result = $conn->query($sql);
                                while ($booking = $result->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td><?php echo $booking['id']; ?></td>
                                        <td><?php echo htmlspecialchars($booking['passenger_name']); ?></td>
                                        <td><?php echo htmlspecialchars($booking['bus_name']); ?></td>
                                        <td><?php echo date('d M Y', strtotime($booking['travel_date'])); ?></td>
                                        <td>₹<?php echo number_format($booking['total_amount'], 2); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $booking['status'] == 'confirmed' ? 'success' : 'warning'; ?>">
                                                <?php echo ucfirst($booking['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                if ($result->num_rows == 0) {
                                    echo '<tr><td colspan="6" class="text-center">No bookings found</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html> 