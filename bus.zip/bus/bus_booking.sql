-- Create the database
CREATE DATABASE IF NOT EXISTS bus_booking;
USE bus_booking;

-- Create the buses table
CREATE TABLE IF NOT EXISTS buses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    travel_date DATE NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    bus_type VARCHAR(50) NOT NULL,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL,
    fare DECIMAL(10,2) NOT NULL,
    seat_layout VARCHAR(20) NOT NULL, -- 2x2, 2x1, etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create seats table
CREATE TABLE IF NOT EXISTS seats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bus_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_type ENUM('sleeper', 'seater') NOT NULL,
    deck ENUM('lower', 'upper') NOT NULL,
    status ENUM('available', 'booked', 'reserved') NOT NULL DEFAULT 'available',
    FOREIGN KEY (bus_id) REFERENCES buses(id),
    UNIQUE KEY unique_seat (bus_id, seat_number)
);

-- Insert sample data
INSERT INTO buses (name, source, destination, travel_date, departure_time, arrival_time, bus_type, total_seats, available_seats, fare, seat_layout) VALUES
('Luxury Express', 'Hazaribagh', 'Ranchi', '2024-03-16', '06:00:00', '10:00:00', 'AC Sleeper', 50, 50, 1500.00, '2x1'),
('Super Deluxe', 'Hazaribagh', 'Ranchi', '2024-03-16', '08:00:00', '12:00:00', 'AC Seater', 45, 45, 1800.00, '2x2'),
('Royal Cruiser', 'Hazaribagh', 'Patna', '2024-03-16', '20:00:00', '06:00:00', 'AC Sleeper', 40, 40, 2500.00, '2x1'),
('City Express', 'Hazaribagh', 'Dhanbad', '2024-03-16', '07:00:00', '11:00:00', 'Non-AC Seater', 56, 56, 800.00, '2x2'),
('Night Rider', 'Hazaribagh', 'Kolkata', '2024-03-16', '18:00:00', '08:00:00', 'AC Sleeper', 35, 35, 3000.00, '2x1');

-- Insert sample seats for Luxury Express (Bus ID 1)
INSERT INTO seats (bus_id, seat_number, seat_type, deck) VALUES
-- Lower Deck
(1, 'L1', 'sleeper', 'lower'),
(1, 'L2', 'sleeper', 'lower'),
(1, 'L3', 'sleeper', 'lower'),
(1, 'L4', 'sleeper', 'lower'),
(1, 'L5', 'sleeper', 'lower'),
(1, 'L6', 'sleeper', 'lower'),
(1, 'L7', 'sleeper', 'lower'),
(1, 'L8', 'sleeper', 'lower'),
(1, 'L9', 'sleeper', 'lower'),
(1, 'L10', 'sleeper', 'lower'),
-- Upper Deck
(1, 'U1', 'sleeper', 'upper'),
(1, 'U2', 'sleeper', 'upper'),
(1, 'U3', 'sleeper', 'upper'),
(1, 'U4', 'sleeper', 'upper'),
(1, 'U5', 'sleeper', 'upper'),
(1, 'U6', 'sleeper', 'upper'),
(1, 'U7', 'sleeper', 'upper'),
(1, 'U8', 'sleeper', 'upper'),
(1, 'U9', 'sleeper', 'upper'),
(1, 'U10', 'sleeper', 'upper'); 